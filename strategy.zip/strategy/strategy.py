from api_helper import ShoonyaApiPy, get_time
from datetime import datetime
import logging
import time
import yaml
import pandas as pd
# from rsi import computeRSI
# from supertrend import Supertrend
import traceback
# import strategy_execution
import math


#sample
logging.basicConfig(level=logging.INFO)

#flag to tell us if the websocket is open
socket_opened = False
atr_period = 10
atr_multiplier = 3
convert_dict = {'into': float,
                'inth': float,
                'intl': float,
                'intc': float} 

#start of our program
api = ShoonyaApiPy()

#application callbacks
def event_handler_order_update(message):
    print("order event: " + str(message))

def event_handler_quote_update(message):
    #e   Exchange #tk  Token #lp  LTP #pc  Percentage change #v   volume #o   Open price #h   High price #l   Low price #c   Close price #ap  Average trade price
    print("quote event: {0}".format(time.strftime('%d-%m-%Y %H:%M:%S')) + str(message))
    

def open_callback():
    global socket_opened
    socket_opened = True
    print('app is connected')
    api.subscribe('NSE|26000')
    #api.subscribe(['NSE|22', 'BSE|522032'])

#yaml for parameters
with open('cred.yml') as f:
    cred = yaml.load(f, Loader=yaml.FullLoader)

def main(interval, rsi_value, straddle_time):
    start_secs = None
    prev_secs = None
    ret = api.login(userid = cred['user'], password = cred['pwd'], twoFA=cred['factor2'], vendor_code=cred['vc'], api_secret=cred['apikey'], imei=cred['imei'])   
    while ret:
        # print('f => find symbol')    
        # print('m => get quotes')
        # print('p => contract info n properties')    
        print('v => get 1 min market data')
        # print('t => get today 1 min market data')
        # print('d => get daily data')
        # print('o => get option chain')
        # print('s => start_websocket')
        print('q => quit')

        try:
            prompt1=input('what shall we do? ').lower() 
            if prompt1 == "s":
                if socket_opened == True:
                    print('websocket already opened')
                    continue    
                response = api.start_websocket(order_update_callback=event_handler_order_update, subscribe_callback=event_handler_quote_update, socket_open_callback=open_callback)
                
            elif prompt1 == 'v':
                start_time = datetime.today().strftime('%d-%m-%Y 00:00:00')
                today_datetime = datetime.now()
                start_secs = get_time(start_time)
                while True:
                    end_time = time.time()
                    response = api.get_time_price_series(exchange='NSE', token='26000', starttime=start_secs, endtime=end_time, interval=interval)
                    if prev_secs is None:
                        prev_secs = start_secs
                        start_secs = end_time
                        dataset = pd.DataFrame.from_dict(response).astype(convert_dict)
                        # dataset['RSI'] = computeRSI(dataset['intc'], rsi_value)
                        # # dataset["intc"]
                        # dataset = dataset.join(Supertrend(dataset, atr_period, atr_multiplier))
                    else:
                        sub_dataset = pd.DataFrame.from_dict(response)
                        sub_dataset["RSI"] = 0.0
                        dataset = pd.concat([sub_dataset, dataset], ignore_index=True).drop_duplicates(subset=["time"])
                        # dataset_rsi = dataset.head(rsi_value+5).copy()
                        # dataset['RSI'] = computeRSI(dataset['intc'], rsi_value)
                    # if int(time.strftime("%I",time.localtime(end_time))) > 3:
                    #     dataset.to_csv('nifty.csv')
                    #     break

                    if math.ceil(dataset.query('time == @straddle_time')['intc']/50)*50:
                        print(f"{straddle_time} Buy nifty at strick at {math.ceil(dataset.query('time == @straddle_time')['intc']/50)*50}")
                        break
                    time.sleep(interval*(60-today_datetime.second))
                
            elif prompt1 == 'q':
                raise KeyboardInterrupt("Quite Program")
                
        except (KeyboardInterrupt, Exception) as exception:
            dataset.to_csv('nifty.csv')
            ret = api.logout()
            traceback.print_exc()
            print(exception)
            break
                     
main(1, 14, datetime.today().strftime('%d-%m-%Y 09:45:00'))
# df = pd.read_csv('nifty.csv')
# df['RSI'] = computeRSI(df['intc'], 14)
# df.to_csv('nifty_rsi.csv')
# print(df)



    