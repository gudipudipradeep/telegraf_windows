Used Gitlab based CI system to deploy the given components on AWS Cloud.
gitlab-ci contains set of stage:
  - pre-setup
  - validate
  - build
  - deploy
  - flush

This gitlab-ci.yaml is executed by gitlab by using gitlab-runner 
  - pre-setup: created the s3 bucket with versioning enabled, because we are saving .tfstate file. Right now I don’t have much time to enable terraboard. 
  - validate: validating the terraform script by using following command “terraform validate”
  - build: running the “terraform plan” command to see before deploying the item cloud.
  - deploy: running the “terraform apply” to deploy the service like vpc, eks, route53 to cloud 
 - flush: running the “terraform destroy” to delete the deployed deployment.

We have created individual terraform code for each service as flexible solution.
Deployed the tomcat application by using helm cart.
Deploy the .war file tomcat manager as of now or we can attach pv, pvc items. 
Enable the below value, if you are deploying from outside the cloud if not it will use IAM Role.
AWS_DEFAULT_REGION            
AWS_ACCESS_KEY_ID                    
AWS_SECRET_ACCESS_KEY


